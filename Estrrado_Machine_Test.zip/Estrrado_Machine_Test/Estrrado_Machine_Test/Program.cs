using Estrrado_Machine_Test.Repository;
using Estrrado_Machine_Test.Service;

var builder = WebApplication.CreateBuilder(args);

// 1. Add connection string
var _connectionString = builder.Configuration.GetConnectionString("ConnectionMVCWin");

// Register connection string as a singleton correctly
builder.Services.AddSingleton(_connectionString);

// Register Repositories & Services
builder.Services.AddScoped<IStudentRepository, StudentRepository>();
builder.Services.AddScoped<IStudentService, StudentService>();
builder.Services.AddScoped<ILoginRepository, LoginRepository>();
builder.Services.AddScoped<ILoginService, LoginService>();
// Add controllers and views
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
