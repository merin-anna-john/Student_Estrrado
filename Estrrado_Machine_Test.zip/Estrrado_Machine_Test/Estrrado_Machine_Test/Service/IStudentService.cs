﻿using Estrrado_Machine_Test.Models;

namespace Estrrado_Machine_Test.Service
{
    public interface IStudentService
    {
        void RegisterStudent(Student student);
    }
}
