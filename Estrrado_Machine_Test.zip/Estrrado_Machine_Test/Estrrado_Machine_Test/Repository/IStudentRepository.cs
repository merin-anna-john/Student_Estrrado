﻿using Estrrado_Machine_Test.Models;

namespace Estrrado_Machine_Test.Repository
{
    public interface IStudentRepository
    {
        void AddStudent(Student student);
    }
}
